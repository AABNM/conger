-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 08, 2016 at 04:33 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `conge`
--

-- --------------------------------------------------------

--
-- Table structure for table `conge`
--

CREATE TABLE IF NOT EXISTS `conge` (
  `cid` bigint(20) unsigned NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `statut` int(11) NOT NULL,
  `commentaire` longtext,
  `e_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conge`
--

INSERT INTO `conge` (`cid`, `date_debut`, `date_fin`, `statut`, `commentaire`, `e_id`) VALUES
(1, '2016-02-10 00:00:00', '2016-02-17 00:00:00', 1, 'Commentaire de test', 1),
(2, '2016-04-01 00:00:00', '2016-04-04 00:00:00', 1, 'Test', 1),
(5, '2016-08-04 00:00:00', '2016-08-15 00:00:00', 1, 'Un autre test', 2),
(6, '2011-01-01 00:00:00', '2011-01-01 00:00:00', 2, NULL, 1),
(7, '2016-06-01 00:00:00', '2016-07-07 00:00:00', 1, 'Conge plat', 3),
(8, '2011-01-01 00:00:00', '2011-04-01 00:00:00', 1, 'Vieux conger', 4),
(9, '2016-05-01 00:00:00', '2016-05-12 00:00:00', 1, 'Pas sure du conger', 4),
(10, '2018-05-04 00:00:00', '2018-06-01 00:00:00', 1, 'COnger Futuriste', 5);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` bigint(20) unsigned NOT NULL,
  `nom` varchar(50) NOT NULL,
  `statut` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `nom`, `statut`) VALUES
(1, 'Aaqil Bhugaloo', 1),
(2, 'John Doe', 0),
(3, 'Francis Berg', 0),
(4, 'Nicolas Pawlazyck', 0),
(5, 'Elise Illois', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `conge`
--
ALTER TABLE `conge`
  ADD UNIQUE KEY `cid` (`cid`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `conge`
--
ALTER TABLE `conge`
  MODIFY `cid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
