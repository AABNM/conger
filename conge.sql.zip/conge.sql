-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 17, 2016 at 03:09 PM
-- Server version: 5.5.47-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `conge`
--

-- --------------------------------------------------------

--
-- Table structure for table `conge`
--

DROP TABLE IF EXISTS `conge`;
CREATE TABLE IF NOT EXISTS `conge` (
  `cid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `statut` int(11) NOT NULL,
  `commentaire` longtext,
  `e_id` int(11) NOT NULL,
  UNIQUE KEY `cid` (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `conge`
--

INSERT INTO `conge` (`cid`, `date_debut`, `date_fin`, `statut`, `commentaire`, `e_id`) VALUES
(1, '2016-02-10 00:00:00', '2016-02-17 00:00:00', 0, 'Commentaire de test', 1),
(2, '2016-04-01 00:00:00', '2016-04-04 00:00:00', 1, 'Test', 1),
(5, '2016-08-04 00:00:00', '2016-08-15 00:00:00', 1, 'Un autre test', 2),
(6, '2011-01-01 00:00:00', '2011-01-01 00:00:00', 2, NULL, 1),
(7, '2016-06-01 00:00:00', '2016-07-07 00:00:00', 1, 'Conge plat', 3),
(8, '2011-01-01 00:00:00', '2011-04-01 00:00:00', 1, 'Vieux conger', 4),
(9, '2016-05-01 00:00:00', '2016-05-12 00:00:00', 1, 'Pas sure du conger', 4),
(10, '2018-05-04 00:00:00', '2018-06-01 00:00:00', 1, 'COnger Futuriste', 5),
(13, '2011-01-01 00:00:00', '2011-01-03 00:00:00', 1, 'sdfsdf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `statut` tinyint(1) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `nom`, `statut`) VALUES
(1, 'Aaqil Bhugaloo', 1),
(2, 'John Doe', 0),
(3, 'Francis Berg', 0),
(4, 'Nicolas Pawlazyck', 0),
(5, 'Elise Illois', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
